import React from "react";

const Legal = () => {

    return (
        <div>
            <p>welcome to the Legal site!</p>
        </div>
    );
};

export default Legal;